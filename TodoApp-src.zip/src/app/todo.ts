export interface Todo {
    id: number,
    todoName: string
}
